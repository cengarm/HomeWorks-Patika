package creditManager;

public class VehicleManager extends  CreditManager { //extends = genişletmek demektir. (Mirası yani inheritance kullanmak için.)

    public void  calculate(){
        System.out.println("Taşıt Kredisi hesaplandı. ");
    }
}
