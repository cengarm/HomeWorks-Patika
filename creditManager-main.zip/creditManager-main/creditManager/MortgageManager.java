package creditManager;

public class MortgageManager extends  CreditManager { //extends = genişletmek demektir. (Mirası yani inheritance kullanmak için.)

    public void  calculate(){
        System.out.println("Konut Kredisi hesaplandı. ");
    }

}
