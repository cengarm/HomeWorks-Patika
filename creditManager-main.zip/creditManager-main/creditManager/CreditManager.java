package creditManager;

public class CreditManager {
    public void  calculate(){
        System.out.println("Kredi hesaplandı. ");
    }
    public void  add(){
        System.out.println("Kredi eklendi. ");
    }

}
