import java.util.Scanner;
public class CircleArea {
    public static void main(String[] args) {

        //double yaricap , pi = 3.14;

        Scanner input = new Scanner(System.in);
        //System.out.print("Yarı çapı giriniz : ");
        //yaricap = input.nextInt();
        //double alan = pi * yaricap * yaricap;
        //double cevre = 2 * pi * yaricap;

        //System.out.println("alan " + alan);
        //System.out.println("cevre " + cevre);
        double r, pi = 3.14, a;

        System.out.print("Yarı çapı giriniz : ");
        r = input.nextInt();
        System.out.print("Merkez açısını giriniz : ");
        a = input.nextInt();

        double dairedilim = (pi*(r*r)* a)/360;
        System.out.print("Dairenin 1 dilim alanı : " + dairedilim);

    }
}
