package Starter;
import java.util.Scanner;
public class ChineseZodiacCalculator {
    public static void main(String[] args) {
        int dt,total;
        Scanner input = new Scanner(System.in);
        System.out.print("Doğum Tarihini Giriniz (Örn : 1997 )! :");

        dt =input.nextInt();
        total = dt % 12;
        if(total == 0){
            System.out.println("Çin zodyağınızın hayvanı:Maymun");
        }else if (total == 2 ){
            System.out.println("Çin zodyağınızın hayvanı: Horoz");

        }else if (total == 3 ) {
            System.out.println("Çin zodyağınızın hayvanı: Köpek");
        }else if (total == 4 ) {
            System.out.println("Çin zodyağınızın hayvanı: Domuz");
        }else if (total == 5 ) {
            System.out.println("Çin zodyağınızın hayvanı: Fare");
        }else if (total == 6 ) {
            System.out.println("Çin zodyağınızın hayvanı: Öküz");
        }else if (total == 7 ) {
            System.out.println("Çin zodyağınızın hayvanı: Kaplan");
        }else if (total == 8 ) {
            System.out.println("Çin zodyağınızın hayvanı: Tavşan");
        }else if (total == 9 ) {
            System.out.println("Çin zodyağınızın hayvanı: Ejderha");
        }else if (total == 10 ) {
            System.out.println("Çin zodyağınızın hayvanı: Yılan");
        }else if (total == 11 ) {
            System.out.println("Çin zodyağınızın hayvanı: At");
        }else if (total == 12 ) {
            System.out.println("Çin zodyağınızın hayvanı: Koyun");
        }



    }

}
// WE CAN USE SWITCH CASE
//Example
// switch(total){
//  case = 0:
// zodyak = monkey
// break ;
// }