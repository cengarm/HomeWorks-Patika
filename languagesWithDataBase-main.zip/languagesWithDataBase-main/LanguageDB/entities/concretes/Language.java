package com.example.LanguageDB.entities.concretes;

import jakarta.persistence.*;
import lombok.*;

@Data
@Table (name = "languages")
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter


public class Language {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
}
