package com.example.LanguageDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LanguageDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(LanguageDbApplication.class, args);
	}

}
