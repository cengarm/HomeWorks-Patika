package com.example.LanguageDB.business.abstracts;

import com.example.LanguageDB.business.request.CreateLanguageRequest;
import com.example.LanguageDB.business.responses.GetAllLanguageRespons;

import java.util.List;

public interface LanguageService {

    List<GetAllLanguageRespons> getAll();
    void add(CreateLanguageRequest createLanguageRequest);
}
