package com.example.LanguageDB.business.concretes;

import com.example.LanguageDB.business.abstracts.LanguageService;
import com.example.LanguageDB.business.request.CreateLanguageRequest;
import com.example.LanguageDB.business.responses.GetAllLanguageRespons;
import com.example.LanguageDB.dataAccess.abstracts.LanguageRepository;
import com.example.LanguageDB.entities.concretes.Language;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LanguageManager implements LanguageService {
    private LanguageRepository languageRepository;
    @Autowired
    public LanguageManager (LanguageRepository languageRepository){
        this.languageRepository = languageRepository;
    }

    @Override
    public List<GetAllLanguageRespons> getAll(){
        List<Language> languages=languageRepository.findAll();
        List<GetAllLanguageRespons> languageRespons = new ArrayList<GetAllLanguageRespons>();
        for(Language language : languages) {
            GetAllLanguageRespons responsItem = new GetAllLanguageRespons();
            responsItem.setId(language.getId());
            responsItem.setName(language.getName());
        }
        return languageRespons;

    }
    @Override
    public void add(CreateLanguageRequest createLanguageRequest){
        Language language = new Language();
        language.setName((createLanguageRequest.getName()));
        this.languageRepository.save(language);

    }

}
