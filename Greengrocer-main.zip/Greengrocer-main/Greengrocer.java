import java.util.Scanner;
public class Greengrocer {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double Armut = 2.14 , Elma = 3.67 , Domates = 1.11, Muz = 0.95;
        double Patlıcan = 5.00, sonuc, a,b,c,d,e,f;

        System.out.print("Armut Kaç Kilo? : ");
        a = input.nextDouble();
        System.out.print("Elma Kaç Kilo? : ");
        b = input.nextDouble();
        System.out.print("Domates Kaç Kilo? : ");
        c = input.nextDouble();
        System.out.print("Muz Kaç Kilo? : ");
        d = input.nextDouble();
        System.out.print("Patlıcan Kaç Kilo? : ");
        f = input.nextDouble();

        sonuc = (a*Armut) + (b*Elma) + (c*Domates) + (d*Muz) + (f*Patlıcan);
        System.out.print("SEPET TOPLAM TUTAR : " + sonuc + " TL");

    }
}
