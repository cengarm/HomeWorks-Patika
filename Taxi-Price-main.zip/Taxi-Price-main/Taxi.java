import java.util.Scanner;

public class Taxi {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double km, perkm = 2.20, total = 10;

        System.out.print("Gidilecek mesafe KM cinsinden : ");
        km = input.nextInt();

        total += (km * perkm);
        total = (total < 20) ? 20 : total;
        System.out.println("Toplam tutar :" + total);
    }
}
