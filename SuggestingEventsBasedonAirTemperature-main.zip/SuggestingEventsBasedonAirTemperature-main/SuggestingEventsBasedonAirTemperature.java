import java.util.Scanner;
public class SuggestingEventsBasedonAirTemperature {
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    double havasicaklik;
        System.out.print("Programa hoşgeldiniz ! Sizin için aktivite önermemizi isterseniz, bulunduğunuz bölgede ki sıcaklığı yazınız : ");
    havasicaklik = input.nextDouble();
    if (havasicaklik <= 5 ) {

        System.out.println("Bu sıcaklıkta 'Kayak' yapmak çok eğlenceli olabilir.");

    } else if (5 < havasicaklik && havasicaklik < 15 ) {
        System.out.println("Bu sıcaklıkta 'Sinemaya' gitmek çok keyifli olabilir.");
    } else if (15 < havasicaklik && havasicaklik < 25 ) {
        System.out.println("Yallah 'Pikniğe'");
    } else
        System.out.println("Bence 'Yüzmeye' gidebilirsin.");

    System.out.println("Bol Bol selfie çekilmeyi unutmayın, iyi eğlenceler.");
    }
}
