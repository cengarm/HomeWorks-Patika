package oopWithNLayeredApp.core.logging;

public interface Logger {
    void log(String data);
}
