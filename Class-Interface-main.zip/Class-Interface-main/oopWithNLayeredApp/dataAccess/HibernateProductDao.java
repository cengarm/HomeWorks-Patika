package oopWithNLayeredApp.dataAccess;

import oopWithNLayeredApp.entities.Product;

public class HibernateProductDao implements ProductDao{
    public void add(Product product) {
        //bu katman db erişim kodu yazılır.. /SQL bilmek gerekiyor.
        System.out.println("Hibernate ile veritabanına eklendi.");
    }
}
