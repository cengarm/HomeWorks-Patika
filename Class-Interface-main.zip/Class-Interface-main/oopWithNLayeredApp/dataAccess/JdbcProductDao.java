package oopWithNLayeredApp.dataAccess;

import oopWithNLayeredApp.entities.Product;

// public : Başka paketlerden erişim için kullanılan kelimedir.
// interface nedir : Arayüz , onu implement eden sınıfın referansını tutabilir.
public class JdbcProductDao implements ProductDao {
  public void add(Product product) {
      //bu katman db erişim kodu yazılır.. /SQL bilmek gerekiyor.
      System.out.print("JDBC ile veritabanına eklendi.");
  }
}
