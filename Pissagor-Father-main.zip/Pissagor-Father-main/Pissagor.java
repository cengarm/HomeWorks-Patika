import java.util.Scanner;
public class Pissagor {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        double a, b, c;


        System.out.print( "Kısa Kenarı Giriniz : ");
        a = input.nextInt();

        System.out.print( "Uzun Kenarı Giriniz : ");
        b = input.nextInt();

        c=Math.sqrt((a*a) + (b*b)) ;
        System.out.print( "Hipo DEĞERİ :  "  + c);

    }
}
