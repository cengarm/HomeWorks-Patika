import java.util.Scanner;
public class BodyMass {
    public static void main(String[] args) {
        double kilo , boy, sonuc ;
        Scanner input = new Scanner(System.in);

        System.out.print("Kilonuzu giriniz ; ");
        kilo = input.nextDouble();

        System.out.print("Boyunuzu giriniz ; ");
        boy = input.nextDouble();

        sonuc = kilo / (boy * boy);
        System.out.print("Vücut Endeksiniz " + sonuc);



    }

}
