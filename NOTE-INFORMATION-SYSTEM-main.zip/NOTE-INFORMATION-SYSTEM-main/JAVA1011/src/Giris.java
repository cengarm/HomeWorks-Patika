public class Giris {
    public static void main(String[] args) {
        System.out.print("Mustafa said Hello");
    }
}
