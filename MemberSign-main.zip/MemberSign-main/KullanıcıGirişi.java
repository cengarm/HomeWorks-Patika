import java.util.Scanner;
public class KullanıcıGirişi {
    public static void main(String[] args)  {
        String username;
        String password, newPassword;
        Scanner input = new Scanner(System.in) ;


        System.out.print("Kullanıcı Adınız : ");
        username = input.nextLine();


        System.out.print("Şifreniz : ");
        password = input.nextLine();

        if (username.equals("patika") && password.equals("java123")){
            System.out.println("Bilgileriniz Doğru Giriş Yaptınız ! ");
        }else{
            System.out.println("Hatalı Giriş Yaptınız !! ");
            System.out.println("Şifrenizi Sıfırlamak ister misiniz ? .");
            int select;
            System.out.println("1-Hayır\n2-Evet");
            System.out.print("Seçiminiz : ");
            select = input.nextInt();
            switch (select){
                case 1:
                    System.out.println("İşleminiz iptal edildi.");
                    break;
                case 2:
                    System.out.println("Lütfen Yeni Şifrenizi Giriniz : ");
                    newPassword = input.next();
                if ((newPassword.equals(password))){
                    System.out.println("Eski Şifreniz ile aynı olamaz");
                }else {
                    System.out.println("Şifreniz Güncellendi.");
                    break;
                }
                default:
                    System.out.println("Hatalı Giriş Yapıldı.");

            }



        }

    }
}
