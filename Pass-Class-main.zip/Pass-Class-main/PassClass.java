import java.util.Scanner;

public class PassClass {
    public static void main(String[] args) {
        int Matematik, Fizik, Türkce, Kimya, Müzik;

        Scanner input = new Scanner(System.in);

        System.out.print("Matematik notunuz : ");
        Matematik = input.nextInt();

        System.out.print("Fizik notunuz : ");
        Fizik = input.nextInt();

        System.out.print("Türkçe notunuz : ");
        Türkce = input.nextInt();

        System.out.print("Kimya notunuz : ");
        Kimya = input.nextInt();

        System.out.print("Müzik notunuz : ");
        Müzik = input.nextInt();

        double avarage = (Matematik+Fizik+Türkce+Kimya+Müzik)/5;
        if ((0 <= Matematik && Matematik <= 100) && (0 <= Fizik&& Fizik <= 100) && (0 <= Türkce && Türkce <= 100) && (0 <= Kimya && Kimya <= 100) && (0 <= Müzik && Müzik <= 100))
            if (avarage < 55 ) {
            System.out.println("Sınıfta Kaldınız Tekrar Görüşmek Üzere !!!!! ");
            System.out.println("Ortalamanız " + avarage);

            }else{
            System.out.println("Sınıfı Geçtiniz Tebrikler !!!!");
            System.out.println("Ortalamanız " + avarage);
            }

        else {
            System.out.println( "Hatalı kodlama sayılar 1 ile 100 arasında olmalı.");
        }


    }
}
