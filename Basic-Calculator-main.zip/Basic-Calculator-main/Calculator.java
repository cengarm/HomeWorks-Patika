import java.util.Scanner;
public class Calculator {
    public static void main(String[] args) {
        double n1, n2, select;

        Scanner input = new Scanner(System.in);
        System.out.print("İlk sayıyı giriniz : ");
        n1=input.nextDouble();
        System.out.print("İkinci sayıyı giriniz : ");
        n2=input.nextDouble();

        System.out.println("1-Toplama\n2-Çıkarma\n3-Çarpma\n4-Bölme");
        System.out.print("Seçiminiz : ");
        select = input.nextDouble();

        switch ((int) select){
            case 1:
                System.out.println("Toplam : " + (n1 + n2));
                break;
            case 2:
                System.out.println("Çıkan : "+ (n1-n2));
                break;
            case 3:
                System.out.println("Çarpma : "+ (n1*n2));
                break;
            case 4:
                System.out.println("Bölme : "+ (n1/n2));
                break;
            default:
                System.out.println("HATALI GİRİŞ YAPTINIZ LÜTFEN 1 DEN 4 KADAR BİR SAYI SEÇİNİZ. ");


        }



    }
}
