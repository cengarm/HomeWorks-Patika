import java.util.Scanner;
public class FlightTicketPriceCalculation {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double mesafe, yaş, yolculuk, normalTutar,secim2indirimi, yasIndirimOrani, mesafeIndirimi,
                total;


        System.out.print("Mesafeyi km cinsinden giriniz ! : ");
        mesafe = input.nextDouble();
        normalTutar = mesafe*0.10 ;
        if ( mesafe <= 0 ) {
            System.out.println("Hatalı yazım . Mesafe 0 olamaz !! ");
        }

        System.out.print("Yaşınızı Giriniz ! : ");
        yaş = input.nextDouble();
        if (yaş < 0 ) {
            System.out.println("Yaş 0 dan küçük olamaz");
        }
        System.out.print("1 => Tek yön , 2 => Gidiş Dönüş ! : ");
        yolculuk = input.nextDouble();
        if (yaş < 12) {
            yasIndirimOrani = (mesafe*0.10)/2;
            if (yolculuk == 2 ) {
                secim2indirimi = normalTutar * 20 /100;
                total = normalTutar - (yasIndirimOrani+secim2indirimi);
                System.out.println("Biletiniz, % 30 daha ilave indirimlidir...:" + total);
            }else {
                total = normalTutar - yasIndirimOrani;
                System.out.print("Biletiniz, % 50 indirimlidir..:" + total);
            }
        } else if (yaş >=12 && yaş <= 24 ) {
           yasIndirimOrani = normalTutar * 10/100;
            if (yolculuk == 2 ) {
                secim2indirimi = normalTutar * 20 /100;
                total = normalTutar - (yasIndirimOrani+secim2indirimi);
                System.out.println("Biletiniz, % 20 daha ilave indirimlidir...:" + total);
            }else {
                total = normalTutar - yasIndirimOrani;
                System.out.print("Biletiniz, % 10 indirimlidir..:" + total); }
        } else if (yaş<=65 && yaş>=25) {

                if (yolculuk == 2 ) {
                    secim2indirimi = normalTutar * 20 /100;
                    total = normalTutar - secim2indirimi;
                    System.out.println("Biletiniz, % 20 daha ilave indirimlidir...:" + total);
                }else {

                    System.out.print("Biletinize indirim uygulanmamıştır.:" + normalTutar);}
        }else if ( yaş > 65 ) {

            yasIndirimOrani = normalTutar * 30/100;
            if (yolculuk == 2 ) {
                secim2indirimi = normalTutar * 20 /100;
                total = normalTutar - (yasIndirimOrani+secim2indirimi);
                System.out.println("Biletiniz, % 20 daha ilave indirimlidir...:" + total);
            }else {
                total = normalTutar - yasIndirimOrani;
                System.out.print("Biletiniz, % 30 indirimlidir..:" + total); }
        }




    }
}
