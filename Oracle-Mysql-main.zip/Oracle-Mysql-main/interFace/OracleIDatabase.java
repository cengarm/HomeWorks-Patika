package interFace;

public class OracleIDatabase implements IDatabase{
    @Override
    public void login() {
        System.out.println("-> Oracle Veritabanına Bağlanıldı.");
    }

    @Override
    public void add() {

        System.out.println("-> Oracle Veritabanına Eklendi.");
    }

    @Override
    public void delete() {

        System.out.println("-> Oracle Veritabanında Silindi.");
    }

    @Override
    public void get() {

        System.out.println("-> Oracle Veritabanına Getirildi.");
    }

    @Override
    public void update() {
        System.out.println("-> Oracle Veritabanında Güncellendi.");
    }


}
