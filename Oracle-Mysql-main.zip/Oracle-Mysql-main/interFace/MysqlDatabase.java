package interFace;

public class MysqlDatabase implements IDatabase {
    @Override
    public void login() {
        System.out.println("-> Mysql Veritabanına Bağlanıldı.");
    }

    @Override
    public void add() {
        System.out.println("-> Mysql Veritabanına Eklendi.");
    }

    @Override
    public void delete() {
        System.out.println("-> Mysql Veritabanında Silindi.");
    }

    @Override
    public void get() {
        System.out.println("-> Mysql Veritabanına Getirildi.");
    }

    @Override
    public void update() {
        System.out.println("-> Mysql Veritabanında Güncellendi.");
    }



}
