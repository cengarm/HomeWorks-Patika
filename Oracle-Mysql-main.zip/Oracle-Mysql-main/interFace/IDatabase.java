package interFace;

public interface IDatabase {
    void login();
    void add();
    void delete();
    void get();
    void update();


}
